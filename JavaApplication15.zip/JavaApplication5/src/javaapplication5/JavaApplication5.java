package javaapplication5;

public class JavaApplication5 {

    public static void main(String[] args) {
       int a = 56;//0101 
        int b = 87;//1010 
         
        System.out.println ("Before Swap: "); 
        System.out.println("a: " +a);
        System.out.println("b: " +b); 
         
        a = a^b;//XOR Sign. 
        b = a^b; 
        a = a^b; 
         
        System.out.println("After Swap: "); 
        System.out.println("a: "+a); 
        System.out.println("b: "+b);
    }
    
}
