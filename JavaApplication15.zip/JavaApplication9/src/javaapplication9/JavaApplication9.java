
package javaapplication9;

public class JavaApplication9 {

    public static void main(String[] args) {
        int i = 1; 
         
        do//Q-9:Print 1 to 10 using a do-while loop. 
        { 
            System.out.println("The Number of Output 'i' is: " +i); 
            i++; 
        } 
        while(i<=10);
    }
    
}
