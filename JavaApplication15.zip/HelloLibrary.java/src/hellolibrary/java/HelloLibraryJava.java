
package hellolibrary.java;

public class HelloLibraryJava {
  static class Library {
        String bookName;
        String authorName;
        int quantity;

        // Constructor
        public Library(String bookName, String authorName, int quantity) {
            this.bookName = bookName;
            this.authorName = authorName;
            this.quantity = quantity;
        }

        // Issue book
        public void issueBook() {
            if (quantity > 0) {
                quantity--;
                System.out.println("Book issued: " + bookName + " by " + authorName);
            } else {
                System.out.println("Sorry, " + bookName + " is not available right now.");
            }
        }

        // Return book
        public void returnBook() {
            quantity++;
            System.out.println("Book returned: " + bookName);
        }

        // Display book info
        public void displayBook() {
            System.out.println("Book: " + bookName + " | Author: " + authorName + " | Available: " + quantity);
        }
    }
    public static void main(String[] args) {
        // Create 3 book objects
        Library b1 = new Library("Java Programming", "James Gosling", 3);
        Library b2 = new Library("Python Basics", "Guido van Rossum", 2);
        Library b3 = new Library("C++ Fundamentals", "Bjarne Stroustrup", 1);

        // Display books
        b1.displayBook();
        b2.displayBook();
        b3.displayBook();

        // Issue books
        b1.issueBook();
        b2.issueBook();
        b3.issueBook();
        b3.issueBook(); // trying to issue more than available

        // Return a book
        b1.returnBook();

        // Display again after transactions
        b1.displayBook();
        b2.displayBook();
        b3.displayBook();
    }
}
    
   

