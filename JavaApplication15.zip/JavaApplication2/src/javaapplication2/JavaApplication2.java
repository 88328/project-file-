package javaapplication2;

public class JavaApplication2 {

    public static void main(String[] args) {
      String name = "Sabbir"; 
       int ID = 1056;//Q-2:Print Employee details (Name, ID, Salary, Annual Salary). 
       double salary = 250000; 
       double AnnualSalary = salary*12; 
        
       System.out.println("Name = " +name); 
       System.out.println ("ID: " +ID); 
       System.out.println ("Salary = " +salary+ " BDT"); 
       System.out.println ("Annual Salary = " +AnnualSalary+ " BDT"); 
    }
    
}
