
package javaapplication8;

public class JavaApplication8 {

    public static void main(String[] args) {
          int i = 1;//Q-8:Print 1 to 10 a using while loop. 
         
        while(i<=10) 
        { 
            System.out.println("The Number of Output 'i' is: " +i); 
            i++; 
        } 
    }
    
}
