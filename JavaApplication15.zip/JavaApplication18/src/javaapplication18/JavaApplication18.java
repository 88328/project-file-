
package javaapplication18;

public class JavaApplication18 {

    public static void main(String[] args) {
        char i; 
// 'a' to 'z' and break in 'o' using a for loop. 
       System.out.print("The Characters from 'a' to 'z' is: "); 
       for(i = 'a'; i<='z'; i++) 
       { 
        System.out.print( i+ " "); 
       if(i=='o') 
        { 
           break; 
        } 
       }
    }
    
}
