
package javaapplication10;

public class JavaApplication10 {

    public static void main(String[] args) {
     double base = 73.0; 
       double height = 9.0;
       double area = 0.5*base*height; 
        
       System.out.println("The area of Triangle is: " + area); 
    }
    
}
