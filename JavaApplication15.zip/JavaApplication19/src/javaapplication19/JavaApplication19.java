
package javaapplication19;

public class JavaApplication19 {

    public static void main(String[] args) {
         int num = 39; 
   
        System.out.println("Quick Price Board: "); 
         
        for (int i=1; i<= 10; i++) 
        { 
            System.out.println(num+ "*" +i+ "="+ (num*i)); 
        }
    }
    
}
