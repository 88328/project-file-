package javaapplication4;


public class JavaApplication4 {

    public static void main(String[] args) {
      int a = 34; 
        int b = 75; 
         
        System.out.println("Before Swapping."); 
        System.out.println ("a = " +a); 
        System.out.println ("b = " +b); 
         
        a = a+b; 
        b = a-b; 
        a = a-b; 
         
        System.out.println("After Swapping."); 
        System.out.println ("a = " +a); 
        System.out.println ("b = " +b);
    }
    
}
