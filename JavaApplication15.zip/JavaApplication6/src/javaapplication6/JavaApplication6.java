
package javaapplication6;

public class JavaApplication6 {

    public static void main(String[] args) {
          int a = 45; 
         
        if(a%2==0)//Q-6:Print a number and find whether it is Even or Odd. 
        { 
            System.out.println("The Printed Number is: Even."); 
        } 
        else if(a%2!=0) 
        { 
            System.out.println("The Printed Number is: Odd."); 
        } 
        else  
        { 
            System.out.println("INVALID INPUT");
    }
    }
}
    

